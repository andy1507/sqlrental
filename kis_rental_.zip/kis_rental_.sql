-- -------------------------------------------------------------
-- TablePlus 3.1.2(296)
--
-- https://tableplus.com/
--
-- Database: kisrental
-- Generation Time: 2020-02-14 13:05:20.2840
-- -------------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `carousel`;
CREATE TABLE `carousel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) NOT NULL,
  `width_gambar` int NOT NULL,
  `width_gambar_x` varchar(255) NOT NULL,
  `jenis_kontak` varchar(255) DEFAULT NULL,
  `icon_kontak` varchar(255) DEFAULT NULL,
  `detail_kontak` varchar(255) DEFAULT NULL,
  `link_kontak` varchar(255) DEFAULT NULL,
  `is_first` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `details`;
CREATE TABLE `details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mobil` int NOT NULL,
  `description` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `kontak`;
CREATE TABLE `kontak` (
  `id` int NOT NULL AUTO_INCREMENT,
  `detail_kontak` varchar(255) DEFAULT NULL,
  `icon_kontak` varchar(255) DEFAULT NULL,
  `link_kontak` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `mobil`;
CREATE TABLE `mobil` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `merk` varchar(255) DEFAULT NULL,
  `harga` decimal(10,0) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `waktu` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `width_gambar` int DEFAULT NULL,
  `width_gambar_x` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
('1', 'kisrentcar', '$2y$12$TYbYJEUpv93qM89vBex4c.5zZPq2X5lNvRCWvmBhWAmT9y322pvEi');

INSERT INTO `carousel` (`id`, `gambar`, `width_gambar`, `width_gambar_x`, `jenis_kontak`, `icon_kontak`, `detail_kontak`, `link_kontak`, `is_first`) VALUES
('1', 'nuova-mercedes-cla.jpg', '100', '%', 'Welcome to <br/> KIS RENTAL', '', '', '', '1'),
('2', 'nuova-mercedes-cla.jpg', '100', '%', 'Whatsapp', 'fa fa-whatsapp', '082153497891', 'https://wa.me/6282153497891', '0'),
('3', 'nuova-mercedes-cla.jpg', '100', '%', 'Telepon', 'fa fa-phone', '082153497891', 'tel:082153497891', '0'),
('4', 'nuova-mercedes-cla.jpg', '100', '%', 'Facebook', 'fa fa-facebook-square', 'Iis Swalow', 'https://m.facebook.com/profile.php?id=100008120893755', '0');

INSERT INTO `details` (`id`, `id_mobil`, `description`) VALUES
('1', '1', 'Spek: Oke\r\nBensin: Oke\r\nMantap: Jiwa'),
('2', '2', 'Spek: Oke\r\nBensin: Oke\r\nMantap: Jiwa');

INSERT INTO `kontak` (`id`, `detail_kontak`, `icon_kontak`, `link_kontak`) VALUES
('1', '082153497891', 'fa fa-whatsapp', 'https://wa.me/6282153497891'),
('2', '085651409679', 'fa fa-whatsapp', 'https://wa.me/6285651409679'),
('3', '082153497891', 'fa fa-phone-square', 'tel:082153497891'),
('4', '085750343591', 'fa fa-phone-square', 'tel:085750343591'),
('5', 'kisrental123@gmail.com', 'fa fa-envelope-square', 'mailto:kisrental123@gmail.com'),
('6', 'Iis Swalow', 'fa fa-facebook-square', 'https://m.facebook.com/profile.php?id=100008120893755');

INSERT INTO `mobil` (`id`, `nama`, `merk`, `harga`, `gambar`, `waktu`, `width_gambar`, `width_gambar_x`) VALUES
('1', 'Toyota Avanza', 'toyota', '350000', 'toyota-avanza.png', '2020-02-12 20:49:33', '300', 'px'),
('2', 'Toyota Innova Reborn', 'toyota', '550000', 'toyota-innova-reborn.png', '2020-02-12 20:50:31', '300', 'px'),
('3', 'Toyota Grand New Innova', 'toyota', '400000', 'toyota-grand-new-innova.png', '2020-02-12 20:50:31', '270', 'px'),
('4', 'Toyota Yaris', 'toyota', '400000', 'toyota-yaris.png', '2020-02-12 20:50:54', '350', 'px'),
('5', 'Toyota Calya', 'toyota', '300000', 'toyota-calya.jpg', '2020-02-12 20:51:19', '280', 'px'),
('6', 'Honda Jazz', 'honda', '400000', 'honda-jazz.jpg', '2020-02-12 20:51:39', '300', 'px'),
('7', 'Daihatsu Sigra', 'daihatsu', '300000', 'daihatsu-sigra.png', '2020-02-12 20:52:01', '250', 'px'),
('8', 'Toyota Agya', 'toyota', '300000', 'toyota-agya.png', '2020-02-12 20:52:38', '250', 'px'),
('9', 'Daihatsu Ayla', 'daihatsu', '300000', 'daihatsu-ayla.png', '2020-02-12 20:53:12', '500', 'px'),
('10', 'Daihatsu Xenia', 'daihatsu', '350000', 'daihatsu-xenia.png', '2020-02-12 20:53:12', '350', 'px');




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
